/*
** my_strlcat.c for my_strlcat in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 12:17:46 2013 loisel_k
** Last update Wed Oct  9 12:18:30 2013 loisel_k
*/

int		my_strlcat(char *dest, char *src, int size)
{
  return (0);
}
