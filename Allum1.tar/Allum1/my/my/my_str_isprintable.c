/*
** my_str_isprintable.c for my_str_isprintable in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 12:10:18 2013 loisel_k
** Last update Wed Oct  9 12:10:43 2013 loisel_k
*/

int		my_str_isprintable(char *str)
{
  return (0);
}
