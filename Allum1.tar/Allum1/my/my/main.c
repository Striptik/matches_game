/*
** main.c for maintest in /home/loisel_k/travail/Librairie/my
** 
** Made by kevin loiseleur
** Login   <loisel_k@epitech.net>
** 
** Started on  Tue Nov 12 17:36:25 2013 kevin loiseleur
** Last update Tue Nov 12 17:52:25 2013 kevin loiseleur
*/

#include "my.h"

int		main(int ac, char **av)
{
  my_put_nbr_base((int)av[1], av[2]);
}
