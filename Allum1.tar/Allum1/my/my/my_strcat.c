/*
** my_strcat.c for my_strcat in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 12:14:46 2013 loisel_k
** Last update Wed Oct  9 12:16:12 2013 loisel_k
*/

char		*my_strcat(char *dest, char *src)
{
  return (dest);
}
