/*
** my_putchar.c for my_putchar in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 09:43:30 2013 loisel_k
** Last update Wed Oct  9 09:43:59 2013 loisel_k
*/

void		my_putchar(char c)
{
  write(1, &c, 1);
}
