/*
** my_str_islower.c for my_str_islower in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 12:07:06 2013 loisel_k
** Last update Wed Oct  9 12:08:37 2013 loisel_k
*/

int		my_str_islower(char *str)
{
  return (0);
}
