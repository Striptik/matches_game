/*
** my_strcapitalize.c for my_strcapitalize in /home/loisel_k/rendu/Piscine-C-lib/my
** 
** Made by loisel_k
** Login   <loisel_k@epitech.net>
** 
** Started on  Wed Oct  9 11:43:16 2013 loisel_k
** Last update Wed Oct  9 11:43:46 2013 loisel_k
*/

char		*my_strcapitalize(char *str)
{
  return (str);
}
