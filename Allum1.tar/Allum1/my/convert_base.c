 /*
** convert_base.c for convert_base in /home/loisel_k/travail/Librairie/my
** 
** Made by kevin loiseleur
** Login   <loisel_k@epitech.net>
** 
** Started on  Sat Nov  9 12:42:20 2013 kevin loiseleur
** Last update Tue Nov 19 20:41:30 2013 kevin loiseleur
*/

